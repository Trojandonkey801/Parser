/**
 * The header file for torun.cpp
 */
#include "queue.h"
node_t *hard_init(vector<string> toinit);
