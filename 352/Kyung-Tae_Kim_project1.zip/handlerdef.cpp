#include "handlerdef.h"
/**
 * @author Kyung-tae Kim
 * @date 10.11.2019
 * This program contains the various handlers for various cases that are local to internal commands.
 * The functions are then organized in a function pointer array, which allows it to be called easily.
 *
 *
 */
void (*fun_ptr_arr[7])(vector<string>) = {handle_cd,handle_clear,handle_dir,handle_environ,handle_argcmd,handle_help,handle_argcmd};

/**
 *  This function handles the internal command cd.
 *  If there are no directory parameters, it is an alias for pwd.
 *  If there is a file directory, it changes directory accordingly
 *  @param vector<string>torun This is the tokenized vector of strings to execute
 *  @return none
 */
void handle_cd(vector<string>torun){
	handle_argcmd("pwd");
}

/**
 *  This function handles the internal command environ.
 *  It is an alias for printenv.
 *  @param vector<string>torun This is the tokenized vector of strings to execute
 *  @return none
 */
void handle_environ(vector<string> torun){
	string pe = "printenv";
	const char *temp = pe.c_str();
	char * ptr = strdup(temp);
	char * argv[] = {ptr,(char *)NULL};
	execvp(argv[0],argv);
	free(ptr);
}

/**
 *  This is a generalized argument executor for a command with no parameters
 *  @param vector<string>torun This is the tokenized vector of strings to execute
 *  @return none
 */
void handle_noargcmd(vector<string> torun){
	const char * temp = torun.back().c_str();
	char * ptr = strdup(temp);
	char *argv[] = {ptr,  (char *)NULL };
	//char temparr[torun->back().length()+1];
	//strcpy(temparr,ptr);
	execvp(argv[0],argv);
	free(ptr);
}

/**
 *  This is a generalized argument executor for a command with only 1 command.
 *  @param string torun This is the command to execute
 *  @return none
 */
void handle_argcmd(string torun){
	char *argv[] = {(char *) torun.c_str(),(char *)NULL};
	execvp(argv[0],argv);
	free(argv[0]);
}

/**
 *  This is a generalized argument executor for a command with an arbitrary number of commands.
 *  This program executes by converting the vector of strings into character pointers.
 *  These char pointers are then placed in an array, and passed to an execvp call
 *  @param vector<string> torun The vector of commands to execute, tokenized.
 *  @return none
 */
void handle_argcmd(vector<string> torun){
	int size = torun.size();
	char *argv[size+1];
	for (int i = 0; i < torun.size(); ++i) {
		string temp = stripout(torun.at(i));
		argv[i] = (char *)malloc(temp.size()+1);
		memcpy(argv[i], temp.c_str(), temp.size()+1);
	}
	argv[size] = (char *)NULL;
	int code;
	code = execvp(argv[0],argv);
	if(code < 0)
		cout << "ERROR OCCURED WITH COMMAND " << argv[0]<< endl;
}

/**
 *  This is a generalized argument executor for a command with an arbitrary number of commands.
 *  It passes back the correct command back in a given array
 *  This program executes by converting the vector of strings into character pointers.
 *  These char pointers are then placed in an array, and then returned.
 *  @param vector<string> torun The vector of commands to execute, tokenized.
 *  @return none
 */
void handle_argcmd_out(vector<string> torun,char **argv[]){
	for (int i = 0; i < torun.size(); ++i) {
		char *ptr = (char *)torun.at(i).c_str();
		cout << ptr << endl;
		*argv[i] = ptr;
	}
	(*argv)[torun.size()] = NULL;
}

/**
 * This is a program that handles the internal command dir.
 * It aliases the command dir to ls, and then passes the vector to the generalized executor
 *  @param vector<string> torun The vector of commands to execute, tokenized.
 *  @return none
 */
void handle_dir(vector<string> torun){
	torun.at(0) = (char *)"ls";
	handle_argcmd(torun);
}

/**
 * This is a program that handles the internal command clr.
 * It aliases to system(clear), as a child process cannot clear the terminal window
 *  @param vector<string> torun The vector of commands to execute, tokenized.
 *  @return none
 */
void handle_clear(vector<string> toclear){
	system("clear");
}

void handle_help(vector<string> torun){
	system("help");
}

