#include <iostream>
#include <vector>
#include <iterator>
#include <sstream>
#include <unistd.h>
#include <cstring>
#include <fstream>
using namespace std;
/**
 * @author Kyung-tae Kim
 * @date 10.11.2019
 * This file contains the headers for the accompnaying cpp file.
 * additionally, it contains the string codes that serve as the lookup table for various codes.
 */
const string codes[8] = {"cd", "clr", "dir", "environ", "echo", "help", "pause", "quit"};
const int PIPE_WRITE = 1;
const int PIPE_READ = 0;
int identify_string(string toID);
void print_vec(vector<string> toprint);
void handle_cd(vector<string> torun);
void handle_noargcmd(vector<string> torun);
vector<string> break_string(string input,char divider,int keep);
vector<string> break_string(string input, vector<char> dividers,int keep);
void handle_argcmd(vector<string> torun);
void handle_dir(vector<string>  directory);
void handle_echo(vector<string>  toecho);
vector<string> read_file(string filename);
bool does_file_exist(const char * fileName);
string strip(string tostrip);
string stripout(string tostrip);
