#include "util.h"
/**
 * This file contains a variety of utility functions for use by the main program
 * identify_string: This function takes the command, and returns an integer value, allowing it to 
 * 					reference the correct index in the function pointer array.
 * print_vec: This function prints out the given vector. For test purposes.
 * find: This is a helper function that checks wheter the given dividers exist in a string.
 * break_string: This function breaks the given string into tokens according to the given vector of characters.
 * break_string: This function breaks the given string into tokesn according to the given character.
 * read_file: This function is responsible for opening and reading a file
 * strip: This function is responsible for removing all spaces from a string.
 * stripout: This function is responsible for removing the outermost unused whitespace
 */
int identify_string(string toID){
	for (int i = 0; i < 11; ++i) {
		if(toID.compare(codes[i]) == 0){
			return i;
		}
	}
	return 4;
}

/*
 * This is a util function to print out the vector
 * THis is mainly a test function
 * @param vector<string> toprint the vector to print
 * @return none
 */
void print_vec(vector<string> toprint){
	cout << "----------" << endl;
	cout << "printing vector" << endl;
	for (int i = 0;i<toprint.size();i++) {
		cout << toprint.at(i) << endl;
	}
	cout << "size:" << toprint.size() << endl;
	cout << "----------" << endl;
}

/**
 * This function takes a string and breaks it up to its components according to " ", ";", "|", and other 
 * reserved keywords
 * The function then places these values inside the vector pointer
 * @input string to break apart
 */
int find(char tofind, vector<char> dividers){
	for (int i = 0; i < dividers.size(); ++i) {
		if(tofind == dividers.at(i))
			return 1;
	}
	return 0;
}

/**
 * This function takes a string and breaks it up to its components according to the given character
 * @param string input The string to break
 * @param char divider The character divider to break the string around
 * @param int keep Whether or not to keep the int divider
 */
vector<string> break_string(string input,char divider,int keep){
	vector<string> toreturn;
	stringstream SStream(input);
	string buffer;
	while(getline(SStream,buffer,divider)){
		toreturn.push_back(buffer);
	}
	return toreturn;
}

/**
 * This function takes a string and breaks it up to its components according to the given character vector
 * @param string input The string to break
 * @param char divider The character divider to break the string around
 * @param int keep Whether or not to keep the int divider
 */
vector<string> break_string(string input, vector<string> * topush, vector<char> dividers,int keep){
	vector<string> toreturn;
	string temp = "";
	for (int i = 0; i< input.length(); ++i){
		if(find(input.at(i),dividers)){
			if(temp.length()>0)
				(*topush).push_back(stripout(temp));
			if(keep == 1)
				(*topush).push_back(string(1,input.at(i)));
			temp = "";
		}
		else
			temp += input.at(i);
	}
	(*topush).push_back(temp);
	return toreturn;
}

/**
 * This function reads a file, and returns each line as an element in a vector
 * @param string filename The name of the file to break
 * @return vector<string> The parsed vector of strings to return
 */
vector<string> read_file(string filename){
	vector<string> topass_back;
	ifstream myfile;
	string line;
	myfile.open (filename);
	if (myfile.is_open())
	{
		while (getline (myfile,line) )
		{
			topass_back.push_back(line);
		}
		myfile.close();
	}
	return topass_back;
}

/**
 * This function checks if the given file exists
 * @param const char *filename The name of the file to check
 * @return bool Whether or not the file exists
 */
bool does_file_exist(const char *fileName){
    ifstream infile(fileName);
    return infile.good();
}

/**
 * This file remvoes all spaces from a given string
 * @param string tostrip The strhing to strip of spaces
 * @return string The string to return
 */
string strip(string tostrip){
	string toreturn = "";
	for (int i = 0; i < tostrip.size(); ++i) {
		if(tostrip.at(i) != (' ')){
			toreturn += tostrip.at(i);
		}
	}
	return toreturn;
}
/**
 * This file remvoes the outermost spaces from a given string.
 * i.e., it would turn "   tostrip   " into "tostrip"
 * @param string tostrip The strhing to strip of spaces
 * @return string The string to return
 */
string stripout(string tostrip){
	string temp = "";
	bool beg = false;
	for (int i = 0; i < tostrip.size(); i++) {
		if(tostrip.at(i) != ' ')
			beg = true;
		if(beg){
			temp += tostrip.at(i);
		}
	}
	beg = false;
	string tempp = "";
	for (int i = temp.length()-1; i >= 0 ; i--) {
		if(temp.at(i) != ' ')
			beg = true;
		if(beg){
			tempp = temp.at(i) + tempp;
		}
	}
	return tempp;
}

