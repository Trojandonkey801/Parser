#include "myshell.h"
#include <sys/types.h>
#include <sys/wait.h>
#define READ_FD 0
#define WRITE_FD 1
/**
 * @author Kyung-tae Kim
 * @date 10.11.2019
 * This file is the highest-level program, containing much of the core implementation.
 * This file has the following parts:
 * main: Handles user input, and breaks and passes the process to appropriate sub calls
 * fork_and execute: takes the program and delegates it to the correct function for piping, writing, etc.
 * in_and_run: responsible for opening a file, and providing it as an input to a command.
 * print_directory: responsible for printing the current directory
 * write_handler: responsible for handling writing out to file, after receiving input from a command
 */
using namespace std;
string currdir;
/**
 * This function sets the current environment to the location that myshell is executing from.
 * @param none
 * @return none
 */
void setenv(){
	std::cout << R"(
 .----------------.  .----------------.  .----------------.  .----------------.  .----------------.  .----------------. 
| .--------------. || .--------------. || .--------------. || .--------------. || .--------------. || .--------------. |
| |     _____    | || |    _______   | || |  ____  ____  | || |  _________   | || |   _____      | || |   _____      | |
| |    |_   _|   | || |   /  ___  |  | || | |_   ||   _| | || | |_   ___  |  | || |  |_   _|     | || |  |_   _|     | |
| |      | |     | || |  |  (__ \_|  | || |   | |__| |   | || |   | |_  \_|  | || |    | |       | || |    | |       | |
| |   _  | |     | || |   '.___`-.   | || |   |  __  |   | || |   |  _|  _   | || |    | |   _   | || |    | |   _   | |
| |  | |_' |     | || |  |`\____) |  | || |  _| |  | |_  | || |  _| |___/ |  | || |   _| |__/ |  | || |   _| |__/ |  | |
| |  `.___.'     | || |  |_______.'  | || | |____||____| | || | |_________|  | || |  |________|  | || |  |________|  | |
| |              | || |              | || |              | || |              | || |              | || |              | |
| '--------------' || '--------------' || '--------------' || '--------------' || '--------------' || '--------------' |
 '----------------'  '----------------'  '----------------'  '----------------'  '----------------'  '----------------' 
)" << '\n';
	cout << "" << endl;
	char work_dir[256];
	char toset[1024] = "shell=";
	string toreturn;
	getcwd(work_dir, sizeof(work_dir));
	strcat(work_dir,"/myshell");
	strcat(toset,work_dir);
	cout <<"setting environ to: "<< toset << endl;
	putenv(toset);
}
/**
 * description : This is the starting point for the program, handling initial user input or bash file readin
 * 				 It is responsible for tokenizing the inputs.
 * @param bashfile name
 * @return 0
 */
int main(int argc, char* argv[]){
	setenv();
	//This segment of code is responsible for checking, and if exists, running the bashfile provided as a command argument.
	if(argc>1){
		if(!does_file_exist(argv[1])){
			cout << "FILE DOES NOT EXIST." << endl;
			exit(0);
		}
		vector<string> file_read = read_file(argv[1]);
		for (int i = 0; i < file_read.size(); ++i) {
			vector<string> parsed;
			parsed = break_string(file_read.at(i),';',1);
			fork_and_execute(parsed);
			parsed.clear();
		}
	}
	//This segment of code is responsible for providing user input, and executing accordingly.
	else{
		while(true){
			vector<string> parsed;
			string input;
			print_directory();
			getline(cin,input);
			if(input.compare("quit") == 0){
				break;
			}
			else if(input.compare("help") == 0){
				vector<string> torun;
				torun.push_back("cat help.txt");
				torun.push_back("more");
				pipe_handler(torun);
			}
			else if(input.compare("pause")==0){
				do{
				}while(cin.get() != '\n');
			}
			else{
				parsed = break_string(input,';',1);
				fork_and_execute(parsed);
			}
		}
	}
	return 0;
}


/**
 * This function prints the current working directory
 * @param none
 * @return none
 */
void print_directory(){
	char work_dir[256];
	string toreturn;
	getcwd(work_dir, sizeof(work_dir));
	currdir = work_dir;
	cout<< currdir << "/myshell" << " :";
}

/**
 * description: This program is responsible for delegating the input values to the correct function
 * @param vector<string> that contains the tokenized values of the individual user input
 * @return 0
 */
int fork_and_execute(vector<string> toexec){
	for (int i = 0; i < toexec.size(); ++i) {
		if(toexec.at(i).find("|") != string::npos){//found pipe, pass to pipe handler
			vector<string> pipe_push;
			pipe_push = break_string(toexec.at(i),'|',1);
			pipe_handler(pipe_push);
		}
		else if(toexec.at(i).find(">") != string::npos){
			vector<string> write_push;
			int count = 0;
			string tocheck = toexec.at(i);
			for (int i = 0; i < tocheck.size(); ++i) {
				if(tocheck.at(i) == '>')
					count ++;
			}
			write_push = break_string(toexec.at(i),'>',0);
			write_handler(write_push,count);
		}
		else if(toexec.at(i).find("<") != string::npos){
			vector<string> in_push;
			in_push = break_string(toexec.at(i),'<',0);
			in_and_run(in_push);
		}
		else{//no pipe operation
			vector<string> broken;
			broken = break_string(stripout(toexec.at(i)),' ',0);
			int loc = identify_string(broken.at(0));
			int towait = 1;
			if(broken.back().compare("&") == 0){
				towait = 0;
				broken.pop_back();
			}
			//This was moved here because child process cannot change directory
			if(loc == 0 && broken.size()>1){
				chdir(broken.back().c_str());
			}
			else{
				pid_t child = fork();
				if(child == 0){
					(*fun_ptr_arr[loc])(broken);
					exit(0);
				}
				else{
					if(towait == 1){
						int status;
						waitpid(child,&status,0);
					}
				}
			}
		}
	}
	return 0;
}

/**
 * description: This function is responsible for running the command necessary, and writing the given output to 
 * 				the provided filename
 * 				additionally, if there is a command to be executed with a file input,
 * 				it delegates to in_and_run, which prints out the output. This output is captured by dup2,
 * 				and written to a file.
 * @param vector<string> the program to execute, tokenized
 * @param arrows the number of > given, to decide wheter to truncate or append.
 * @return none
 */
void write_handler(vector<string> toexec, int arrows){
	string writefrom = stripout(toexec.at(0));
	string writeto = stripout(toexec.back());
	bool exists = does_file_exist(writeto.c_str());
	if(!exists){
		cout << "FILE DOES NOT EXIST." << writeto << " will be created" << endl;
	}
	string line;
	int my_pipe[2];
	if(pipe(my_pipe) == -1)
	{
		fprintf(stderr, "Error creating pipe\n");
	}
	pid_t child_id;
	child_id = fork();
	if(child_id == -1)
	{
		fprintf(stderr, "Fork error\n");
	}
	else if(child_id == 0){
		fstream myfile;
		if(!exists)
			myfile.open(writeto,ios::out);
		else if(arrows == 1){
			myfile.open(writeto,ios::out);
		}
		else{
			myfile.open(writeto,ios::app);
		}
		//This segment of code reads out all from pipe[read]
		close(my_pipe[WRITE_FD]);
		std::string s;
		char ch;
		while (read(my_pipe[READ_FD], &ch, 1) > 0)
		{
			if (ch != 0)
				s.push_back(ch);
			else{
				s.clear();
			}
		}
		myfile << s;
		myfile.close();
		close(my_pipe[READ_FD]);
		exit(0);
	}
	else{
		pid_t child2 = fork();
		if(child2 == 0){
			close(my_pipe[0]);
			dup2(my_pipe[1],1); // redirect stdout
			close(my_pipe[1]);
			if(writefrom.find("<") != string::npos){ //need to handle cases with double brackets.
				vector<string> topass;
				topass = break_string(writefrom,'<',0);
				in_and_run(topass);
			}
			else{ // no double in, out redirection
				vector<string> command;
				command = break_string(stripout(writefrom),' ',0);
				int loc = identify_string(command.at(0));
				(*fun_ptr_arr[loc])(command);
			}
			exit(0);
		}
		else{
			int status;
			close(my_pipe[0]);
			close(my_pipe[1]);
			waitpid(child_id,&status,0);
			waitpid(child2,&status,0);
		}
	}
}

void in_and_run(vector<string> toexec){
	string writefrom = stripout(toexec.back());
	string writeto = toexec.at(0);
	bool exists = does_file_exist(writefrom.c_str());
	if(!exists)
		cout << "NO FILE" << endl;
	int my_pipe[2];
	if(pipe(my_pipe) == -1)
	{
		fprintf(stderr, "Error creating pipe\n");
	}
	pid_t child_id;
	child_id = fork();
	if(child_id == -1)
	{
		fprintf(stderr, "Fork error\n");
	}
	else if(child_id == 0){
		vector<string> command;
		command = break_string(stripout(writeto),' ',0);
		dup2(my_pipe[0], 0); // redirect stdout
		close(my_pipe[1]);
		close(my_pipe[0]);
		int loc = identify_string(command.at(0));
		(*fun_ptr_arr[loc])(command);
		//handle_argcmd_out(command,argv);
		exit(0);
	}
	else{
		pid_t child2 = fork();
		if(child2 == 0){
			fstream myfile(writefrom);
			string total = "";
			if (myfile.is_open())
			{
				string line;
				while ( getline (myfile,line) )
				{
					total += line;
					total += "\n";
				}
				myfile.close();
			}
			close(my_pipe[READ_FD]);
			write(my_pipe[WRITE_FD], total.c_str(), total.length()+1);
			exit(0);
		}
		else{
			int status;
			close(my_pipe[0]);
			close(my_pipe[1]);
			waitpid(child_id,&status,0);
			waitpid(child2,&status,0);
		}
	}
}

/**
 * This program handles the pipe out into more, by forking and then dup2ing the output into more.
 * @param vector<string> the tokenized program to execute
 * @return 0
 */
int pipe_handler(vector<string> toexec){
	string com1 = toexec.at(0);
	int my_pipe[2];
	if(pipe(my_pipe) == -1)
	{
		fprintf(stderr, "Error creating pipe\n");
	}

	pid_t child_id;
	child_id = fork();
	if(child_id == -1)
	{
		fprintf(stderr, "Fork error\n");
	}
	if(child_id == 0) // child process
	{
		dup2(my_pipe[0],0);
		close(my_pipe[0]);
		close(my_pipe[1]);
		execlp("more","more",(char *)0);
		exit(0);
	}
	else{
		pid_t child2 = fork();
		if(child2 < 0)
			cout << "error" << endl;
		if(child2 == 0){
			vector<string> command;
			command = break_string(stripout(com1),' ',0);
			int loc = identify_string(command.at(0));
			dup2(my_pipe[1], 1); // redirect stdout
			close(my_pipe[0]); // child doesn't read
			close(my_pipe[1]);
			(*fun_ptr_arr[loc])(command);
			exit(0);
		}
		else{
			int status,status1;
			close(my_pipe[0]);
			close(my_pipe[1]);
			if(waitpid(child_id,&status1,0) == -1){
				exit(EXIT_FAILURE);
			}
			if(waitpid(child2,&status,0) == -1){
				exit(EXIT_FAILURE);
			}
		}
	}
	return 0;
}

