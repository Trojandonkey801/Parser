#include <iostream>
#include <vector>
#include <iterator>
#include <sstream>
#include <unistd.h>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <array>

#include "handlerdef.h"

/**
 * @author Kyung-tae Kim
 * @date 10.11.2019
 * This files serves as the header file for the functios detailed in the accompnaying cpp file.
 *
 *
 */
void print_directory();
int parser(std::string toparse);
int fork_and_execute(vector<string> toexec);
int pipe_handler(vector<string> toexec);
void write_handler(vector<string> toexec, int arrows);
void in_and_run(vector<string> toexec);
